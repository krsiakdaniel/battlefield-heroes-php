<div>
    <p id="div-footer">
        <span class="float-l">
          <a href="http://www.battlefieldheroes.com/" rel="external" title="External Window">BATTLEFIELD HEROES</a>
          &#124;	<a href="http://www.dice.se/" rel="external" title="External Window">DICE</a>
          &#124;	<a href="http://www.ea.com/" rel="external" title="External Window">EA</a>
          &#124;	<a href="http://www.i3d.net/" rel="external" title="External Window">i3D.net</a>
      </span>
      <span class="float-r">
          &#169; 2009 |
          <a href="http://krsiak.cz/" rel="external" title="External Window">Krsiak Daniel</a> |
          &#124;	<a href="faq-site-map.php">Site Map</a>
      </span>
  </p>
</div>