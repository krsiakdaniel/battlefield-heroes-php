
	<script type="text/javascript" src="js/external-window.js"></script>
	<!-- ADD THIS - S -->
	<script type="text/javascript" src="http://s7.addthis.com/js/250/addthis_widget.js#username=krysak4ever"></script>
	<script type="text/javascript">
	var addthis_config = {ui_cobrand: "BF HEROES"}
	var addthis_config = {ui_delay: 50}
	var addthis_config = {services_compact: 'gmail, google, delicious, digg, blogger, live, more'}
	</script>
	<!-- ADD THIS - E -->
