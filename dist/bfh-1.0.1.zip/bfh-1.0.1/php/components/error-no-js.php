<noscript>

<div id="div-error-no-js">

<div class="custom-div-yellow">
<table>
<tr>
	<td>
	<img src="images/icon/32x32/trans-warning.png" width="32" height="32" alt="ERROR" />
	</td>
	<td>
	<ul class="list-square">
		<li>
		<strong>Your browser has <a href="http://www.faq.krsiak.cz/javascript.php" rel="external" title="External Window">Javascript</a> turned off.</strong>
		</li>
		<li>
		<strong>Visit our <a href="http://www.faq.krsiak.cz/" rel="external" title="External Window">support</a> section!</strong>
		</li>
	</ul>
	</td>
</tr>
</table>
</div>

</div>

</noscript>
