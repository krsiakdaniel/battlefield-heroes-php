
	<link rel="shortcut icon" href="images/favicon.ico" />

	<link rel="stylesheet" type="text/css" href="css/bfh-fansite.css" />
	<link rel="stylesheet" type="text/css" href="css/menu.css" />
	<!--[if IE]><link rel="stylesheet" type="text/css" media="screen" href="css/msie.css" /><![endif]-->
	<!--[if IE 6]><link rel="stylesheet" type="text/css" media="screen" href="css/msie6.css" /><![endif]-->