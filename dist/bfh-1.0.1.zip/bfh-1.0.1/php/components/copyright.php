
	<!--
	* WEBMASTER + ADMIN:
	*
	* WWW: http://www.krsiak.cz/
	*
	* GSM: +420 734 496 308
	* E-mail: krsiak.cz@gmail.com
	*
	* Motto: "Never give up. Practice makes perfection."
	-->