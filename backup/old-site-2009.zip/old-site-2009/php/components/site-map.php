<div class="custom-div-blue">
<ul class="list-square">
<li><a href="index.php"><strong>Home</strong></a></li>
</ul>

<ul class="list-square">
<li><a href="armies.php"><strong>Armies</strong></a>
	<ul>
	<li><a href="armies-royal-army.php">Royal army</a></li>
	<li><a href="armies-national-army.php">National army</a></li>
	</ul>
</li>

<li><a href="classes.php"><strong>Classes</strong></a>
	<ul>
	<li><a href="classes-soldier.php">Soldier</a></li>
	<li><a href="classes-gunner.php">Gunner</a></li>
	<li><a href="classes-commando.php">Commando</a></li>
	</ul>
</li>

<li><a href="abilities.php"><strong>abilities</strong></a>
	<ul>
	<li><a href="abilities-soldier.php">Soldier</a></li>
	<li><a href="abilities-gunner.php">Gunner</a></li>
	<li><a href="abilities-commando.php">Commando</a></li>
	</ul>
</li>

<li><a href="gameplay.php"><strong>gameplay</strong></a>
	<ul>
	<li><a href="gameplay-appearance.php">Appearance</a></li>
	<li><a href="gameplay-maps.php">Maps</a></li>
	<li><a href="gameplay-vehicles.php">Vehicles</a></li>
	<li><a href="gameplay-widgets.php">Widgets</a></li>
	</ul>
</li>

<li><a href="media.php"><strong>media</strong></a>
	<ul>
	<li><a href="gallery-screenshots/media-screenshots.php">Screenshots</a></li>
	<li><a href="gallery-wallpapers/media-wallpapers.php">Wallpapers</a></li>
	<li><a href="media-music.php">Music</a></li>
	<li><a href="media-video.php">Video</a></li>
	<li><a href="media-signature.php">Signature</a></li>
	</ul>	
</li>

<li><a href="links.php"><strong>links</strong></a>
	<ul>
	<li><a href="links-portal.php">Portal</a></li>
	<li><a href="links-miscellaneous.php">Miscellaneous</a></li>
	<li><a href="links-server.php">i3D.net</a></li>
	</ul>
</li>

<li><a href="contact.php"><strong>contact</strong></a>
	<ul>
	<li><a href="contact-social-networks.php">Social networks</a></li>
	</ul>
</li>

<li><a href="faq.php"><strong>Faq</strong></a>
	<ul>
	<li><a href="faq-activex-ie.php">ActiveX</a></li>
	<li><a href="faq-flash.php">Flash</a></li>
	<li><a href="faq-js.php">Javascript</a></li>
	<li><a href="site-map.php">Site map</a></li>
	</ul>
</li>
</ul>
</div>