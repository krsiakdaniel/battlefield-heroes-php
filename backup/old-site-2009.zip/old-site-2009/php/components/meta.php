
	<meta http-equiv="content-language" content="en" />
	<meta http-equiv="content-type" content="text/html; charset=utf-8" />

	<meta name="description" content="Battlefield Heroes" />
	<meta name="keywords" content="battlefield heroes, battlefield heros, battlefield hero, bf heroes, bf heros, bf hero, bfheroes, bfheros, bfhero, bfh, battlefield, play now, playnow, EA, DICE, Krysak4eveR, Krsiak Daniel" />
	<meta name="robots" content="all" />

	<meta name="author" content="Krsiak Daniel" />
	<meta name="copyright" content="Krsiak Daniel - www.krsiak.cz" />
