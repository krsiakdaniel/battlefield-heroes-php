<!--
<span class="float-r">
<a href="#" title="Czech language" class="margin-sub-menu-right-side" id="acz"><img src="images/icon/cz.png" width="50" height="16" alt="CZE" class="border-none" /></a>
</span>
-->
	<!-- ADD THIS - S -->
	<span class="float-r">

	<span class="addthis_toolbox addthis_default_style" id="add-this">
		<a class="addthis_button_favorites" title="ADD TO BOOKMARKS"></a>
		<a class="addthis_button_facebook" title="FACEBOOK"></a>
		<a class="addthis_button_twitter" title="TWITTER"></a>
		<a class="addthis_button_email" title="E-MAIL"></a>

		<span class="addthis_separator">&#124;</span>
		<a href="http://www.addthis.com/bookmark.php?v=250&amp;username=krysak4ever" class="addthis_button_compact"></a>
	</span>
	</span>
	<!-- ADD THIS - E -->
