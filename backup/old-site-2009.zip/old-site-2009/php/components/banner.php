<div>
<!-- SPACE FROM TOP - S -->
<br />
<!-- SPACE FROM TOP - E -->

<!-- BANNER - S -->
<a href="index.php" id="ahome">
<img src="images/trans-banner.png" width="1680" height="313" alt="BATTLEFIELD HEROES - HOMEPAGE" class="border-none" />
</a>
<!-- BANNER - E -->
</div>